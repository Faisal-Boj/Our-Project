﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Project
{
    public abstract class Ab_Account
    {
        protected string name;
        protected int indexId;// we will use this to take the index of the specific item in list

        protected string ret; // this field allow you to return to the main.
        protected bool L1 = true;
        protected bool L2 = true;
        protected bool L3 = true;
        // these bool fields just for check and ending loop

        //Lists of account
        protected static List<string> ListName = new List<string>(); //List for containing Name
        protected static List<string> ListEmail = new List<string>(); //List for containing Email
        protected static List<string> ListPassword = new List<string>(); //List for containing Password
        protected static List<string> ListDate = new List<string>(); //List for containing Date
        protected static List<long> ListIdOfShoppingCart = new List<long>(); //List for containing Id of shopping cart
        protected static List<double> AccountBalance = new List<double>();//Account balance
        //List of product
        //Laptop (with its name and price and id and features)
        protected static List<string> nameOfProduct = new List<string>
        {
            "HP Laptop","Lenovo Laptop","Dell Laptop","Apple Laptop","MSI Laptop",
            "Razer Laptop","Asus Laptop","Acer Laptop","Microsoft Laptop","Samsung Laptop"
        };
        protected static List<double> priceOfProduct = new List<double>
        {
            450.43,470.01,300.00,700.21,690.91,680.22,590.43,550.33,500.00,390.90
        };
        protected static List<int> laptopId = new List<int>
        {
            1000,1001,1002,1003,1004,1005,1006,1007,1008,1009

        };
        protected static List<string> features = new List<string>
        {
                "touch-Ram<8GB>-Core-i5","without touch-Ram<8GB>-Core-i5","without touch-Ram<6GB>-Core-i3",
                "touch-Ram<16GB>-Core-i9","touch-Ram<8GB>-Core-i7","whitout touch-Ram<8GB>-Core-i7",
                "without touch-Ram<8GB>-Core-i7","without touch-Ram<8GB>-Core-i7","without touch-Ram<8GB>-Core-i5",
                "without touch-Ram<4GB>-Core-i5"
        };
        //Processor (with its name and price and id)
        protected static List<string> processor = new List<string>
        {
            "Core-i3","Core-i5","Core-i7","AMD-A4","AMD-A6",
            "AMD-A8","AMD-A10","AMD-Ryzen-7","AMD-Ryzen-5","AMD-Ryzen-3"
        };
        protected static List<double> priceOfProcessor = new List<double>
        {
            200.22,300.99,580.32,480.32,730.44,790.24,830.55,670.66,420.99,370.66
        };
        protected static List<int> processorId = new List<int>()
        {
            2000,2001,2002,2003,2004,2005,2006,2007,2008,2009
        };
        //Computer accessories (with its name and price and id)
        protected static List<string> computerAccessories = new List<string>()
        {
            "Mouse","Headphone","Joystick","HDMI","Mouse-pad"
            ,"USB","Type-C","Keyboard","Microphone","Webcam"
        };
        protected static List<double> priceOfAccessories = new List<double>()
        {
            13,8,30,10,22,25,5,50,30,44
        };
        protected static List<int> accessoriesId = new List<int>()
        {
            3000,3001,3002,3003,3004,3005,3006,3007,3008,3009
        };

        public abstract void PrintAll();
        public abstract void PrintSpecificItem();
    }
}