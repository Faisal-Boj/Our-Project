﻿using System;

namespace Project
{
    class Program
    {
        static void Main(string[] args)
        {
            string input;
            Account A = new Account();
            BrowseOrSearch BoS = new BrowseOrSearch();
            Shopping_cart shp = new Shopping_cart();
            Sale S = new Sale();
            
            while (true)
            {
                Console.WriteLine();
                Console.WriteLine();
                Console.WriteLine();
                Console.ForegroundColor = ConsoleColor.Gray;
                Console.WriteLine("                             ^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^");
                Console.ForegroundColor = ConsoleColor.Cyan;
                Console.WriteLine("                             |             -- Welcome to the shopping system --                |   ");
                Console.WriteLine("                             |                                                                 |");
                Console.WriteLine("                             |                                                                 |");
                Console.WriteLine("                             | [1] About Account          [2] Show Your product in the store   |" );
                Console.WriteLine("                             |                                                                 |");
                Console.WriteLine("                             |                                                                 |");
                Console.WriteLine("                             | [3] Browse our store       [4] Buy                              |" );
                Console.WriteLine("                             |                                                                 |");
                Console.WriteLine("                             |                                                                 |");
                Console.WriteLine("                             | [5] Shopping cart          [6] Wish Cart                        |" );
                Console.WriteLine("                             |                                                                 |");
                Console.WriteLine("                             |                                                                 |");
                Console.WriteLine("                             |                    [7] Exit Program                             |");
                Console.WriteLine("                             |                                                                 |");
                Console.WriteLine("                             |_________________________________________________________________|");
                Console.Write("                             ");
                object ob1 = Console.ReadLine();
                input = Convert.ToString(ob1);
                string choose;

                if (input == "1")
                {
                    returnToTheCreateAccount:
                    Console.Clear();
                    Console.WriteLine();
                    Console.WriteLine();
                    Console.WriteLine();
                    Console.ForegroundColor = ConsoleColor.Gray;
                    Console.WriteLine("                             ^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^");
                    Console.ForegroundColor = ConsoleColor.Cyan;
                    Console.WriteLine("                             |                      -- About Account --                        |");
                    Console.WriteLine("                             |                                                                 |");
                    Console.WriteLine("                             |                                                                 |");
                    Console.WriteLine("                             | [1] Create Account          [2] Get information of your account |");
                    Console.WriteLine("                             |                                                                 |");
                    Console.WriteLine("                             |                                                                 |");
                    Console.WriteLine("                             |                     [3] Return                                  |");
                    Console.WriteLine("                             |                                                                 |");
                    Console.WriteLine("                             |                                                                 |");
                    Console.WriteLine("                             |                                                                 |");
                    Console.WriteLine("                             |                                                                 |");
                    Console.WriteLine("                             |                                                                 |");
                    Console.WriteLine("                             |                                                                 |");
                    Console.WriteLine("                             |                                                                 |");
                    Console.WriteLine("                             |_________________________________________________________________|");
                    choose = Console.ReadLine();
                    if(choose == "1")
                    {
                        Console.Clear();
                        A.CreateAccount();
                    }
                    else if(choose == "2")
                    {
                        Console.Clear();
                        A.PrintAll();
                    }
                    else if(choose == "3")
                    {
                        Console.Clear();
                    }
                    else
                    {
                        goto returnToTheCreateAccount;
                    }
                }
                else if(input == "2")
                {
                    Console.Clear();
                    Console.WriteLine();
                    Console.WriteLine();
                    Console.WriteLine();
                    Console.ForegroundColor = ConsoleColor.Gray;
                    Console.WriteLine("                             ^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^");
                    Console.WriteLine("                             |               -- Show Your product in the store --              |");
                    Console.WriteLine("                             |                                                                 |");
                    Console.WriteLine("                             |                                                                 |");
                    Console.WriteLine("                             |     [1] To show your product in Laptop section                  |");
                    Console.WriteLine("                             |                                                                 |");
                    Console.WriteLine("                             |                                                                 |");
                    Console.WriteLine("                             |     [2] To show your product in Processor section               |");
                    Console.WriteLine("                             |                                                                 |");
                    Console.WriteLine("                             |                                                                 |");
                    Console.WriteLine("                             |     [3] To show your product in Accessories section             |");
                    Console.WriteLine("                             |                                                                 |");
                    Console.WriteLine("                             |                                                                 |");
                    Console.WriteLine("                             |                                                                 |");
                    Console.WriteLine("                             |                                                                 |");
                    Console.WriteLine("                             |_________________________________________________________________|");
                    Console.ForegroundColor = ConsoleColor.Yellow;
                    Console.WriteLine("                                -- Note : You must have an account to unlock this section --   ");
                    Console.WriteLine();
                    if(A.CheckAccount() == true)
                    {
                        returnToShowproduct:
                        Console.Clear();
                        Console.WriteLine();
                        Console.WriteLine();
                        Console.WriteLine();
                        Console.ForegroundColor = ConsoleColor.Gray;
                        Console.WriteLine("                             ^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^");
                        Console.ForegroundColor = ConsoleColor.Cyan;
                        Console.WriteLine("                             |               -- Show Your product in the store --              |");
                        Console.WriteLine("                             |                                                                 |");
                        Console.WriteLine("                             |                                                                 |");
                        Console.WriteLine("                             |     [1] To show your product in Laptop section                  |");
                        Console.WriteLine("                             |                                                                 |");
                        Console.WriteLine("                             |                                                                 |");
                        Console.WriteLine("                             |     [2] To show your product in Processor section               |");
                        Console.WriteLine("                             |                                                                 |");
                        Console.WriteLine("                             |                                                                 |");
                        Console.WriteLine("                             |     [3] To show your product in Accessories section             |");
                        Console.WriteLine("                             |                                                                 |");
                        Console.WriteLine("                             |                                                                 |");
                        Console.WriteLine("                             |     [4] Return                                                  |");
                        Console.WriteLine("                             |                                                                 |");
                        Console.WriteLine("                             |_________________________________________________________________|");
                        choose = Console.ReadLine();
                        if (choose == "1")
                        {
                            Console.Clear();
                            S.ProductShow();
                        }
                        else if (choose == "2")
                        {
                            Console.Clear();
                            S.ProcessorShow();
                        }
                        else if (choose == "3")
                        {
                            Console.Clear();
                            S.AccessoriesShow();
                        }
                        else if(choose == "4")
                        {
                            Console.Clear();
                        }
                        else
                        {
                            goto returnToShowproduct;
                        }
                    }
                }
                else if(input == "3")
                {
                    Console.Clear();
                    Console.WriteLine();
                    Console.WriteLine();
                    Console.WriteLine();
                    Console.ForegroundColor = ConsoleColor.Gray;
                    Console.WriteLine("                             ^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^");
                    Console.ForegroundColor = ConsoleColor.Cyan;
                    Console.WriteLine("                             |                     -- Browse our store --                      |");
                    Console.WriteLine("                             |                                                                 |");
                    Console.WriteLine("                             |                                                                 |");
                    Console.WriteLine("                             |               [1] Browse          [2] Search                    |");
                    Console.WriteLine("                             |                                                                 |");
                    Console.WriteLine("                             |                                                                 |");
                    Console.WriteLine("                             |                         [3] Return                              |");
                    Console.WriteLine("                             |                                                                 |");
                    Console.WriteLine("                             |                                                                 |");
                    Console.WriteLine("                             |                                                                 |");
                    Console.WriteLine("                             |                                                                 |");
                    Console.WriteLine("                             |                                                                 |");
                    Console.WriteLine("                             |                                                                 |");
                    Console.WriteLine("                             |                                                                 |");
                    Console.WriteLine("                             |_________________________________________________________________|");
                    choose = Console.ReadLine();
                    if (choose == "1")
                    {
                        Console.Clear();
                        BoS.PrintAll();
                    }
                    else if(choose == "2")
                    {
                        Console.Clear();
                        BoS.PrintSpecificItem();
                    }
                }
                else if (input == "4")
                {
                    Console.Clear();
                    Console.WriteLine();
                    Console.WriteLine();
                    Console.WriteLine();
                    Console.ForegroundColor = ConsoleColor.Gray;
                    Console.WriteLine("                             ^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^");
                    Console.ForegroundColor = ConsoleColor.Cyan;

                    Console.WriteLine("                             |                     -- Browse our store --                      |");
                    Console.WriteLine("                             |                                                                 |");
                    Console.WriteLine("                             |                                                                 |");
                    Console.WriteLine("                             |               [1] Put item in shopping cart                     |");
                    Console.WriteLine("                             |                                                                 |");
                    Console.WriteLine("                             |               [2] Put item in Wish cart                         |");
                    Console.WriteLine("                             |                                                                 |");
                    Console.WriteLine("                             |               [3] Return                                        |");
                    Console.WriteLine("                             |                                                                 |");
                    Console.WriteLine("                             |                                                                 |");
                    Console.WriteLine("                             |                                                                 |");
                    Console.WriteLine("                             |                                                                 |");
                    Console.WriteLine("                             |                                                                 |");
                    Console.WriteLine("                             |                                                                 |");
                    Console.WriteLine("                             |_________________________________________________________________|");
                    Console.Write("                             ");
                    choose = Console.ReadLine();
                    if(choose == "1")
                    {
                        Console.Clear();
                        BoS.PrintAll();
                        shp.shop();
                    }
                    else if(choose == "2")
                    {
                        Console.Clear();
                        BoS.PrintAll();
                        shp.Wish();
                    }
                }
                else if(input == "5")
                {
                    Console.Clear();
                    Console.WriteLine();
                    Console.WriteLine();
                    Console.WriteLine();
                    Console.ForegroundColor = ConsoleColor.Gray;
                    Console.WriteLine("                             ^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^");
                    Console.ForegroundColor = ConsoleColor.Cyan;
                    Console.WriteLine("                             |                     -- Browse our store --                      |");
                    Console.WriteLine("                             |                                                                 |");
                    Console.WriteLine("                             |                                                                 |");
                    Console.WriteLine("                             |               [1] To Show your shopping cart                    |");
                    Console.WriteLine("                             |                                                                 |");
                    Console.WriteLine("                             |               [2] To Delet item from shopping cart              |");
                    Console.WriteLine("                             |                                                                 |");
                    Console.WriteLine("                             |               [3] Return                                        |");
                    Console.WriteLine("                             |                                                                 |");
                    Console.WriteLine("                             |                                                                 |");
                    Console.WriteLine("                             |                                                                 |");
                    Console.WriteLine("                             |                                                                 |");
                    Console.WriteLine("                             |                                                                 |");
                    Console.WriteLine("                             |                                                                 |");
                    Console.WriteLine("                             |_________________________________________________________________|");
                    Console.Write("                             ");
                    choose = Console.ReadLine();
                    if (choose == "1")
                    {
                        Console.Clear();
                        shp.PrintAll();
                    }
                    else if (choose == "2")
                    {
                        Console.Clear();
                        shp.Delet();
                    }

                }
                else if(input == "6")
                {
                    Console.Clear();
                    Console.WriteLine("1. To show your wishing cart");
                    Console.WriteLine("2. To Delet item from wishing cart");
                    Console.Clear();
                    Console.WriteLine();
                    Console.WriteLine();
                    Console.WriteLine();
                    Console.ForegroundColor = ConsoleColor.Gray;
                    Console.WriteLine("                             ^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^");
                    Console.ForegroundColor = ConsoleColor.Cyan;
                    Console.WriteLine("                             |                     -- Browse our store --                      |");
                    Console.WriteLine("                             |                                                                 |");
                    Console.WriteLine("                             |                                                                 |");
                    Console.WriteLine("                             |               [1] To show your wishing cart                     |");
                    Console.WriteLine("                             |                                                                 |");
                    Console.WriteLine("                             |               [2] To Delet item from wishing cart               |");
                    Console.WriteLine("                             |                                                                 |");
                    Console.WriteLine("                             |               [3] Return                                        |");
                    Console.WriteLine("                             |                                                                 |");
                    Console.WriteLine("                             |                                                                 |");
                    Console.WriteLine("                             |                                                                 |");
                    Console.WriteLine("                             |                                                                 |");
                    Console.WriteLine("                             |                                                                 |");
                    Console.WriteLine("                             |                                                                 |");
                    Console.WriteLine("                             |_________________________________________________________________|");
                    Console.Write("                             ");
                    choose = Console.ReadLine();
                    if(choose == "1")
                    {
                        Console.Clear();
                        shp.Wish("Print wishing cart");
                    }
                    else if (choose == "2")
                    {
                        Console.Clear();
                        shp.Wish("Delet", "Item");
                    }
                }
               
                else if (input == "7")
                {
                    break;
                }
                else
                {
                    Console.Clear();
                }
            }
        }
    }
}
