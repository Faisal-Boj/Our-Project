﻿using System;
using System.Text;

namespace Project
{
    class Sale : Ab_Account
    {
        string n; //to enter the name (name) of product
        double p; //to enter the price of product
        private double priceOf; // this variable will take the price (p) of the product;
        public override void PrintAll()
        {}
        public override void PrintSpecificItem()
        {}

        private static int idInitLaptop;
        private static int idProcessor;
        private static int idAccessories;

        static Sale()
        {
            idInitLaptop = 1009;
            idProcessor = 2009;
            idAccessories = 3009;
        }

        public void ProductShow()
        {
            L1 = true;
            L2 = true;
            L3 = true;
            Console.WriteLine();
            Console.WriteLine();
            Console.WriteLine();
            Console.ForegroundColor = ConsoleColor.Gray;
            Console.WriteLine("                             ^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^");
            Console.WriteLine("                             |               -- Show Your product in the store --              |");
            Console.WriteLine("                             |                                                                 |");
            Console.WriteLine("                             |                                                                 |");
            Console.WriteLine("                             |     [1] To show your product in Laptop section                  |");
            Console.WriteLine("                             |                                                                 |");
            Console.WriteLine("                             |                                                                 |");
            Console.WriteLine("                             |     [2] To show your product in Processor section               |");
            Console.WriteLine("                             |                                                                 |");
            Console.WriteLine("                             |                                                                 |");
            Console.WriteLine("                             |     [3] To show your product in Accessories section             |");
            Console.WriteLine("                             |                                                                 |");
            Console.WriteLine("                             |                                                                 |");
            Console.WriteLine("                             |     [4] Return                                                  |");
            Console.WriteLine("                             |                                                                 |");
            Console.WriteLine("                             |_________________________________________________________________|");
            while (L1 == true)
            {
                Here:
                if(L1 == false)
                {
                    break;
                }
                if (L2 != false)
                {
                    while (L2 == true)
                    {
                        Console.ForegroundColor = ConsoleColor.Cyan;
                        Console.Write("                             - Enter the name of product : ");
                        n = Console.ReadLine();
                        if (n.Length != 0 && char.IsLetter(n[0]))
                        {
                            name = n;
                            L2 = false;
                        }
                        else
                        {
                            Console.ForegroundColor = ConsoleColor.Red;
                            Console.WriteLine("                             - There is a mistake in the name");
                            Console.WriteLine();
                            Console.ForegroundColor = ConsoleColor.Gray;
                            Console.WriteLine("                             - [0] To return to the main ");
                            Console.WriteLine("                             - press (ENTER) to continue");
                            ret = Console.ReadLine();
                            if (ret == "0")
                            {
                                Console.Clear();
                                L1 = false;
                                goto Here;
                            }
                        }
                    }
                }
                else if(L3 != false)
                {
                    while (L3 == true)
                    {
                        Console.ForegroundColor = ConsoleColor.Cyan;
                        Console.Write("                             - Enter the price of product : ");
                        try
                        {
                            p = Convert.ToDouble(Console.ReadLine());
                            if (p < 15000)
                            {
                                priceOf = p;
                                L3 = false;
                            }
                            else
                            {
                                Console.ForegroundColor = ConsoleColor.Red;
                                Console.WriteLine("                             - Price must be lesser than 10000");
                                Console.WriteLine();
                                Console.ForegroundColor = ConsoleColor.Gray;
                                Console.WriteLine("                             - [0] To return to the main ");
                                Console.WriteLine("                             - press (ENTER) to continue");
                                ret = Console.ReadLine();
                                if (ret == "0")
                                {
                                    Console.Clear();
                                    L1 = false;
                                    L2 = true;
                                    goto Here;
                                }
                            }
                        }
                        catch
                        {
                            Console.ForegroundColor = ConsoleColor.Red;
                            Console.WriteLine("                             - only number.");
                            Console.WriteLine();
                            Console.ForegroundColor = ConsoleColor.Gray;
                            Console.WriteLine("                             - [0] To return to the main ");
                            Console.WriteLine("                             - press (ENTER) to continue");
                            ret = Console.ReadLine();
                            if (ret == "0")
                            {
                                Console.Clear();
                                L1 = false;
                                L2 = true;
                                goto Here;
                            }
                        }
                    }
                }
                else if(L2 == false && L3 == false)
                {
                    nameOfProduct.Add(name);
                    idInitLaptop++;
                    Console.WriteLine("                             - ID of product : " + idInitLaptop);
                    laptopId.Add(idInitLaptop);
                    priceOfProduct.Add(priceOf);
                    Console.ForegroundColor = ConsoleColor.Cyan;
                    Console.Write("                             - Enter features : ");
                    string feat = Console.ReadLine();
                    Console.WriteLine();
                    Console.ForegroundColor = ConsoleColor.Green;
                    Console.WriteLine("                                      ___________________________");
                    Console.WriteLine("                                      |                         |");
                    Console.WriteLine("                                      | Successfuly operation!! |");
                    Console.WriteLine("                                      |_________________________|");
                    Console.WriteLine();
                    features.Add(feat);
                    ret = Console.ReadLine();
                    Console.Clear();
                    L1 = false;
                }
            }
            
        }
        public void ProcessorShow()
        {
            L1 = true;
            L2 = true;
            L3 = true;
            Console.WriteLine();
            Console.WriteLine();
            Console.WriteLine();
            Console.ForegroundColor = ConsoleColor.Gray;
            Console.WriteLine("                             ^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^");
            Console.WriteLine("                             |               -- Show Your product in the store --              |");
            Console.WriteLine("                             |                                                                 |");
            Console.WriteLine("                             |                                                                 |");
            Console.WriteLine("                             |     [1] To show your product in Laptop section                  |");
            Console.WriteLine("                             |                                                                 |");
            Console.WriteLine("                             |                                                                 |");
            Console.WriteLine("                             |     [2] To show your product in Processor section               |");
            Console.WriteLine("                             |                                                                 |");
            Console.WriteLine("                             |                                                                 |");
            Console.WriteLine("                             |     [3] To show your product in Accessories section             |");
            Console.WriteLine("                             |                                                                 |");
            Console.WriteLine("                             |                                                                 |");
            Console.WriteLine("                             |     [4] Return                                                  |");
            Console.WriteLine("                             |                                                                 |");
            Console.WriteLine("                             |_________________________________________________________________|");
            while (L1 == true)
            {
                Here:
                if(L1 == false)
                {
                    break;
                }
                if(L2 != false)
                {
                    while (L2 == true)
                    {
                        Console.ForegroundColor = ConsoleColor.Cyan;
                        Console.Write("                             - Enter the name of processor : ");
                        n = Console.ReadLine();
                        if (n.Length != 0 && char.IsLetter(n[0]))
                        {
                            name = n;
                            L2 = false;
                        }
                        else
                        {
                            Console.ForegroundColor = ConsoleColor.Red;
                            Console.WriteLine("                             - There is a mistake in the name");
                            Console.WriteLine();
                            Console.ForegroundColor = ConsoleColor.Gray;
                            Console.WriteLine("                             - [0] To return to the main ");
                            Console.WriteLine("                             - press (ENTER) to continue");
                            ret = Console.ReadLine();
                            if (ret == "0")
                            {
                                Console.Clear();
                                L1 = false;
                                goto Here;
                            }
                        }
                    }
                }
                else if(L3 != false)
                {
                    while (L3 == true)
                    {
                        Console.ForegroundColor = ConsoleColor.Cyan;
                        Console.Write("                             - Enter the price of processor : ");
                        try
                        {
                            p = Convert.ToDouble(Console.ReadLine());
                            if (p < 3000)
                            {
                                priceOf = p;
                                L3 = false;
                            }
                            else
                            {
                                Console.ForegroundColor = ConsoleColor.Red;
                                Console.WriteLine("                             - Price must be lesser than 3000 ");
                                Console.WriteLine();
                                Console.ForegroundColor = ConsoleColor.Gray;
                                Console.WriteLine("                             - [0] To return to the main ");
                                Console.WriteLine("                             - press (ENTER) to continue");
                                ret = Console.ReadLine();
                                if (ret == "0")
                                {
                                    Console.Clear();
                                    L1 = false;
                                    L2 = true;
                                    goto Here;
                                }
                            }
                        }
                        catch
                        {
                            Console.ForegroundColor = ConsoleColor.Red;
                            Console.WriteLine("                             - only number.");
                            Console.WriteLine();
                            Console.ForegroundColor = ConsoleColor.Gray;
                            Console.WriteLine("                             - [0] To return to the main ");
                            Console.WriteLine("                             - press (ENTER) to continue");
                            ret = Console.ReadLine();
                            if (ret == "0")
                            {
                                Console.Clear();
                                L1 = false;
                                L2 = true;
                                goto Here;
                            }
                        }
                    }
                }
                else if(L2 == false && L3 == false)
                {
                    processor.Add(name);
                    idProcessor++;
                    Console.WriteLine("                             - ID of processor : " + idProcessor);
                    Console.WriteLine();
                    Console.ForegroundColor = ConsoleColor.Green;
                    Console.WriteLine("                                      ___________________________");
                    Console.WriteLine("                                      |                         |");
                    Console.WriteLine("                                      | Successfuly operation!! |");
                    Console.WriteLine("                                      |_________________________|");
                    Console.WriteLine();
                    processorId.Add(idProcessor);
                    priceOfProcessor.Add(priceOf);
                    ret = Console.ReadLine();
                    Console.Clear();
                    L1 = false;
                }
            }
        }
        public void AccessoriesShow()
        {
            L1 = true;
            L2 = true;
            L3 = true;
            Console.WriteLine();
            Console.WriteLine();
            Console.WriteLine();
            Console.ForegroundColor = ConsoleColor.Gray;
            Console.WriteLine("                             ^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^");
            Console.WriteLine("                             |               -- Show Your product in the store --              |");
            Console.WriteLine("                             |                                                                 |");
            Console.WriteLine("                             |                                                                 |");
            Console.WriteLine("                             |     [1] To show your product in Laptop section                  |");
            Console.WriteLine("                             |                                                                 |");
            Console.WriteLine("                             |                                                                 |");
            Console.WriteLine("                             |     [2] To show your product in Processor section               |");
            Console.WriteLine("                             |                                                                 |");
            Console.WriteLine("                             |                                                                 |");
            Console.WriteLine("                             |     [3] To show your product in Accessories section             |");
            Console.WriteLine("                             |                                                                 |");
            Console.WriteLine("                             |                                                                 |");
            Console.WriteLine("                             |     [4] Return                                                  |");
            Console.WriteLine("                             |                                                                 |");
            Console.WriteLine("                             |_________________________________________________________________|");
            while (L1 == true)
            {
                Here:
                if (L1 == false)
                {
                    break;
                }
                if (L2 != false)
                {
                    while (L2 == true)
                    {
                        Console.ForegroundColor = ConsoleColor.Cyan;
                        Console.Write("                             - Enter the name of accessor : ");
                        n = Console.ReadLine();
                        if (n.Length != 0 && char.IsLetter(n[0]))
                        {
                            name = n;
                            L2 = false;
                        }
                        else
                        {
                            Console.ForegroundColor = ConsoleColor.Red;
                            Console.WriteLine("                             - There is a mistake in the name");
                            Console.WriteLine();
                            Console.ForegroundColor = ConsoleColor.Gray;
                            Console.WriteLine("                             - [0] To return to the main ");
                            Console.WriteLine("                             - press (ENTER) to continue");
                            ret = Console.ReadLine();
                            if (ret == "0")
                            {
                                Console.Clear();
                                L1 = false;
                                goto Here;
                            }
                        }
                    }
                }
                else if (L3 != false)
                {
                    while (L3 == true)
                    {
                        Console.ForegroundColor = ConsoleColor.Cyan;
                        Console.Write("                             - Enter the price of accessor : ");
                        try
                        {
                            p = Convert.ToDouble(Console.ReadLine());
                            if (p < 450)
                            {
                                priceOf = p;
                                L3 = false;
                            }
                            else
                            {
                                Console.ForegroundColor = ConsoleColor.Red;
                                Console.WriteLine("                             - Price must be lesser than 350");
                                Console.WriteLine();
                                Console.ForegroundColor = ConsoleColor.Gray;
                                Console.WriteLine("                             - [0] To return to the main ");
                                Console.WriteLine("                             - press (ENTER) to continue");
                                ret = Console.ReadLine();
                                if (ret == "0")
                                {
                                    Console.Clear();
                                    L1 = false;
                                    L2 = true;
                                    goto Here;
                                }
                            }
                        }
                        catch
                        {
                            Console.ForegroundColor = ConsoleColor.Red;
                            Console.WriteLine("                             - only number.");
                            Console.WriteLine();
                            Console.ForegroundColor = ConsoleColor.Gray;
                            Console.WriteLine("                             - [0] To return to the main ");
                            Console.WriteLine("                             - press (ENTER) to continue");
                            ret = Console.ReadLine();
                            if (ret == "0")
                            {
                                Console.Clear();
                                L1 = false;
                                L2 = true;
                                goto Here;
                            }
                        }
                    }
                }
                else if (L2 == false && L3 == false)
                {
                    computerAccessories.Add(name);
                    idAccessories++;
                    Console.WriteLine("                             - ID of accessor : " + idAccessories);
                    accessoriesId.Add(idAccessories);
                    priceOfAccessories.Add(priceOf);
                    Console.WriteLine();
                    Console.ForegroundColor = ConsoleColor.Green;
                    Console.WriteLine("                                      ___________________________");
                    Console.WriteLine("                                      |                         |");
                    Console.WriteLine("                                      | Successfuly operation!! |");
                    Console.WriteLine("                                      |_________________________|");
                    Console.WriteLine();
                    ret = Console.ReadLine();
                    Console.Clear();
                    L1 = false;
                }
            }
        }
    }
}
