﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Project
{
    class DOB 
    {
        private int day;
        private int month;
        private int year;
        public void set(int d, int m, int y)// receive the value from account
        {
            this.day = d;
            this.month = m;
            this.year = y;
        }
        public bool Date()//check if value is true or not
        {
            if (day > 31 || month > 12 || year > 2022)
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine("                             - Invalid date ");
                Console.WriteLine();
                Console.ForegroundColor = ConsoleColor.Gray;
                return false;
            }
            else
                return true;

        }
        public bool CheckDate()// check if date is true or not
        {

            if (Date() == true)
            {
                Console.WriteLine("                             - Date is : " + day + "-" + month + "-" + year);
                return false;
            }
            else
                Console.WriteLine("                             - please enter date again");
            return true;

        }
    }
}
