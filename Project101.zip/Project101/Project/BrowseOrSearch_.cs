﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Project
{
    public class BrowseOrSearch : Ab_Account
    {
        private string select; //to select between section
        private int find;
        //we will use this field (find) to search about specific item in specific section

        public override void PrintAll() //this method to print all item of specific section
        {
            Console.WriteLine();
            Console.WriteLine();
            Console.WriteLine();
            Console.ForegroundColor = ConsoleColor.Gray;
            Console.WriteLine("                             ^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^");
            Console.WriteLine("                             |                     -- Browse our store --                      |");
            Console.WriteLine("                             |                                                                 |");
            Console.WriteLine("                             |                                                                 |");
            Console.WriteLine("                             |               [1] Browse          [2] Search                    |");
            Console.WriteLine("                             |                                                                 |");
            Console.WriteLine("                             |                                                                 |");
            Console.WriteLine("                             |                         [3] Return                              |");
            Console.WriteLine("                             |                                                                 |");
            Console.WriteLine("                             |                                                                 |");
            Console.WriteLine("                             |                                                                 |");
            Console.WriteLine("                             |                                                                 |");
            Console.WriteLine("                             |                                                                 |");
            Console.WriteLine("                             |                                                                 |");
            Console.WriteLine("                             |                                                                 |");
            Console.WriteLine("                             |_________________________________________________________________|");
            Console.Write("                             ");
            select = Console.ReadLine();
            if(select == "1")
            {
                for (int i = 0; i < nameOfProduct.Count; i++)
                {
                    Console.ForegroundColor = ConsoleColor.Gray;
                    Console.WriteLine();
                    Console.WriteLine("                             | - Name of laptop : " + nameOfProduct[i]);
                    Console.WriteLine("                             | - -----------");
                    Console.WriteLine("                             | - Price : " + priceOfProduct[i]);
                    Console.WriteLine("                             | - -----------");
                    Console.WriteLine("                             | - laptop ID : " + laptopId[i]);
                    Console.WriteLine("                             | - -----------");
                    Console.WriteLine("                             | - Featuers : " + features[i]);
                    Console.WriteLine();
                }
            }
            else if(select == "2")
            { 
                for(int  i = 0; i < processor.Count; i++)
                {
                    Console.ForegroundColor = ConsoleColor.Gray;
                    Console.WriteLine();
                    Console.WriteLine("                             | - Name of processor : " + processor[i]);
                    Console.WriteLine("                             | - -----------");
                    Console.WriteLine("                             | - Price : " + priceOfProcessor[i]);
                    Console.WriteLine("                             | - -----------");
                    Console.WriteLine("                             | - processor ID : " + processorId[i]);
                    Console.WriteLine();
                }
            }
            else if(select == "3")
            {
                for(int i = 0; i < computerAccessories.Count; i++)
                {
                    Console.ForegroundColor = ConsoleColor.Gray;
                    Console.WriteLine();
                    Console.WriteLine("                             | - Name of Accessor : " + computerAccessories[i]);
                    Console.WriteLine("                             | - -----------");
                    Console.WriteLine("                             | - Price : " + priceOfAccessories[i]);
                    Console.WriteLine("                             | - -----------                             ");
                    Console.WriteLine("                             | - Accessor ID : " + accessoriesId[i]);
                    Console.WriteLine();
                }
            }
        }
        public override void PrintSpecificItem() //to search about item by its id 
        {
            Console.Clear();
            Console.WriteLine();
            Console.WriteLine();
            Console.WriteLine();
            Console.ForegroundColor = ConsoleColor.Gray;
            Console.WriteLine("                             ^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^");
            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.WriteLine("                             |                      -- About Account --                        |");
            Console.WriteLine("                             |                                                                 |");
            Console.WriteLine("                             |                                                                 |");
            Console.WriteLine("                             | [1] Search in Laptop          [2] Search in processor           |");
            Console.WriteLine("                             |                                                                 |");
            Console.WriteLine("                             |                                                                 |");
            Console.WriteLine("                             |               [3] Search in computer accessory                  |");
            Console.WriteLine("                             |                                                                 |");
            Console.WriteLine("                             |                                                                 |");
            Console.WriteLine("                             |                                                                 |");
            Console.WriteLine("                             |                                                                 |");
            Console.WriteLine("                             |                                                                 |");
            Console.WriteLine("                             |                                                                 |");
            Console.WriteLine("                             |                                                                 |");
            Console.WriteLine("                             |_________________________________________________________________|");
            Console.Write("                             ");
            select = Console.ReadLine();
            if (select == "1")
            {
                while (true)
                {
                    try
                    {
                        Console.Clear();
                        Console.WriteLine();
                        Console.WriteLine();
                        Console.WriteLine();
                        Console.ForegroundColor = ConsoleColor.Gray;
                        Console.WriteLine("                             ^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^");
                        Console.WriteLine("                             |                      -- About Account --                        |");
                        Console.WriteLine("                             |                                                                 |");
                        Console.WriteLine("                             |                                                                 |");
                        Console.WriteLine("                             | [1] Search in Laptop          [2] Search in processor           |");
                        Console.WriteLine("                             |                                                                 |");
                        Console.WriteLine("                             |                                                                 |");
                        Console.WriteLine("                             |               [3] Search in computer accessory                  |");
                        Console.WriteLine("                             |                                                                 |");
                        Console.WriteLine("                             |                                                                 |");
                        Console.WriteLine("                             |                                                                 |");
                        Console.WriteLine("                             |                                                                 |");
                        Console.WriteLine("                             |                                                                 |");
                        Console.WriteLine("                             |                                                                 |");
                        Console.WriteLine("                             |                                                                 |");
                        Console.WriteLine("                             |_________________________________________________________________|");
                        Console.ForegroundColor = ConsoleColor.Cyan;
                        Console.Write("                             - ID of the product : ");
                        find = Convert.ToInt32(Console.ReadLine());
                        if (laptopId.Contains(find))
                        {
                            indexId = laptopId.IndexOf(find);
                            Console.ForegroundColor = ConsoleColor.Gray;

                            Console.WriteLine();
                            Console.WriteLine("                             - Name of product : " + nameOfProduct[indexId]);
                            Console.WriteLine("                             -----------");
                            Console.WriteLine("                             - Price : " + priceOfProduct[indexId]);
                            Console.WriteLine("                             -----------");
                            Console.WriteLine("                             - Product ID : " + laptopId[indexId]);
                            Console.WriteLine("                             -----------");
                            Console.WriteLine("                             - Featuers : " + features[indexId]);
                            Console.WriteLine();
                            Console.WriteLine("                             0. To return to the main");
                            Console.WriteLine("                             - press (ENTER) to continue");
                            ret = Console.ReadLine();
                            if (ret == "0")
                            {
                                break;
                            }
                        }
                        else
                        {
                            Console.ForegroundColor = ConsoleColor.Red;
                            Console.WriteLine("                             - This product is not in the system");
                            Console.ForegroundColor = ConsoleColor.Gray;
                            Console.WriteLine();
                            Console.WriteLine("                             0. To return to the main");
                            Console.WriteLine("                             - press (ENTER) to continue");
                            ret = Console.ReadLine();
                            if (ret == "0")
                            {
                                break;
                            }
                        }
                    }
                    catch
                    {
                        Console.ForegroundColor = ConsoleColor.Red;
                        Console.WriteLine("                             - Error index");
                        Console.WriteLine();
                        Console.ForegroundColor = ConsoleColor.Gray;
                        Console.WriteLine("                             0. To return to the main");
                        Console.WriteLine("                             - press (ENTER) to continue");
                        ret = Console.ReadLine();
                        if (ret == "0")
                        {
                            break;
                        }
                    }
                }
            }
            else if (select == "2")
            {
                while (true)
                {
                    try
                    {
                        Console.Clear();
                        Console.WriteLine();
                        Console.WriteLine();
                        Console.WriteLine();
                        Console.ForegroundColor = ConsoleColor.Gray;
                        Console.WriteLine("                             ^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^");
                        Console.WriteLine("                             |                      -- About Account --                        |");
                        Console.WriteLine("                             |                                                                 |");
                        Console.WriteLine("                             |                                                                 |");
                        Console.WriteLine("                             | [1] Search in Laptop          [2] Search in processor           |");
                        Console.WriteLine("                             |                                                                 |");
                        Console.WriteLine("                             |                                                                 |");
                        Console.WriteLine("                             |               [3] Search in computer accessory                  |");
                        Console.WriteLine("                             |                                                                 |");
                        Console.WriteLine("                             |                                                                 |");
                        Console.WriteLine("                             |                                                                 |");
                        Console.WriteLine("                             |                                                                 |");
                        Console.WriteLine("                             |                                                                 |");
                        Console.WriteLine("                             |                                                                 |");
                        Console.WriteLine("                             |                                                                 |");
                        Console.WriteLine("                             |_________________________________________________________________|");
                        Console.ForegroundColor = ConsoleColor.Cyan;
                        Console.Write("                             - ID of the product : ");
                        find = Convert.ToInt32(Console.ReadLine());
                        if (processorId.Contains(find))
                        {
                            indexId = processorId.IndexOf(find);
                            Console.ForegroundColor = ConsoleColor.Gray;

                            Console.WriteLine();
                            Console.WriteLine("                             - Name of processor : " + processor[indexId]);
                            Console.WriteLine("                             -----------");
                            Console.WriteLine("                             - Price : " + priceOfProcessor[indexId]);
                            Console.WriteLine("                             -----------");
                            Console.WriteLine("                             - Product ID : " + processorId[indexId]);
                            Console.WriteLine();
                            Console.WriteLine("                             0. To return to the main");
                            Console.WriteLine("                             - press (ENTER) to continue");
                            ret = Console.ReadLine();
                            if (ret == "0")
                            {
                                break;
                            }
                        }
                        else
                        {
                            Console.ForegroundColor = ConsoleColor.Red;
                            Console.WriteLine("                             - This product is not in the system");
                            Console.WriteLine();
                            Console.ForegroundColor = ConsoleColor.Gray;
                            Console.WriteLine("                             0. To return to the main");
                            Console.WriteLine("                             - press (ENTER) to continue");
                            ret = Console.ReadLine();
                            if (ret == "0")
                            {
                                break;
                            }
                        }
                    }
                    catch
                    {
                        Console.ForegroundColor = ConsoleColor.Red;
                        Console.WriteLine("                             - Try again and enter ID of the processor");
                        Console.WriteLine();
                        Console.ForegroundColor = ConsoleColor.Gray;
                        Console.WriteLine("                             0. To return to the main");
                        Console.WriteLine("                             - press (ENTER) to continue");
                        ret = Console.ReadLine();
                        if (ret == "0")
                        {
                            break;
                        }
                    }
                }
            }
            else if(select == "3")
            {
                while (true)
                {
                    try
                    {
                        Console.Clear();
                        Console.WriteLine();
                        Console.WriteLine();
                        Console.WriteLine();
                        Console.ForegroundColor = ConsoleColor.Gray;
                        Console.WriteLine("                             ^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^");
                        Console.WriteLine("                             |                      -- About Account --                        |");
                        Console.WriteLine("                             |                                                                 |");
                        Console.WriteLine("                             |                                                                 |");
                        Console.WriteLine("                             | [1] Search in Laptop          [2] Search in processor           |");
                        Console.WriteLine("                             |                                                                 |");
                        Console.WriteLine("                             |                                                                 |");
                        Console.WriteLine("                             |               [3] Search in computer accessory                  |");
                        Console.WriteLine("                             |                                                                 |");
                        Console.WriteLine("                             |                                                                 |");
                        Console.WriteLine("                             |                                                                 |");
                        Console.WriteLine("                             |                                                                 |");
                        Console.WriteLine("                             |                                                                 |");
                        Console.WriteLine("                             |                                                                 |");
                        Console.WriteLine("                             |                                                                 |");
                        Console.WriteLine("                             |_________________________________________________________________|");
                        Console.ForegroundColor = ConsoleColor.Cyan;
                        Console.Write("                             - ID of the product : ");
                        find = Convert.ToInt32(Console.ReadLine());
                        if (accessoriesId.Contains(find))
                        {
                            indexId = accessoriesId.IndexOf(find);
                            Console.ForegroundColor = ConsoleColor.Gray;

                            Console.WriteLine();
                            Console.WriteLine("                             - Name of product : " + computerAccessories[indexId]);
                            Console.WriteLine("                             -----------");
                            Console.WriteLine("                             - Price : " + priceOfAccessories[indexId]);
                            Console.WriteLine("                             -----------");
                            Console.WriteLine("                             - Product ID : " + accessoriesId[indexId]);
                            Console.WriteLine();
                            Console.WriteLine("                             0. To return to the main");
                            Console.WriteLine("                             - press (ENTER) to continue");
                            ret = Console.ReadLine();
                            if (ret == "0")
                            {
                                break;
                            }
                        }
                        else
                        {
                            Console.ForegroundColor = ConsoleColor.Red;
                            Console.WriteLine("                             - This product is not in the system");
                            Console.WriteLine();
                            Console.ForegroundColor = ConsoleColor.Gray;
                            Console.WriteLine("                             0. To return to the main");
                            Console.WriteLine("                             - press (ENTER) to continue");
                            ret = Console.ReadLine();
                            if (ret == "0")
                            {
                                break;
                            }
                        }
                    }
                    catch
                    {
                        Console.ForegroundColor = ConsoleColor.Red;
                        Console.WriteLine("                             Try again and enter ID of the item");
                        Console.WriteLine();
                        Console.ForegroundColor = ConsoleColor.Gray;
                        Console.WriteLine("                             0. To return to the main");
                        Console.WriteLine("                             - press (ENTER) to continue");
                        ret = Console.ReadLine();
                        if (ret == "0")
                        {
                            break;
                        }
                    }
                }
            }
        }
    }
}