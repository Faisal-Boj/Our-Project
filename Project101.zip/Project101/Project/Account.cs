﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Text;

namespace Project
{
    public class Account : Ab_Account
    {
        private string password;
        private string email;
        private long balance;
        private static long idOfShoppingcart; // we will use this to give the user shopping cart id
        DOB dob = new DOB(); // object of class DOB to allow as to call its method

        static Account()
        {
            idOfShoppingcart = 19100;
        }
        //to generate shopping cart id for the user

        public void CreateAccount()// this method to create account
        {
            Console.WriteLine();
            Console.WriteLine();
            Console.WriteLine();
            Console.ForegroundColor = ConsoleColor.Gray;
            Console.WriteLine("                             ^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^");
            Console.WriteLine("                             |                      -- About Account --                        |   ");
            Console.WriteLine("                             |                                                                 |");
            Console.WriteLine("                             |                                                                 |");
            Console.WriteLine("                             | [1] Create Account          [2] Get information of your account |");
            Console.WriteLine("                             |                                                                 |");
            Console.WriteLine("                             |                                                                 |");
            Console.WriteLine("                             |                     [3] Return                                  |");
            Console.WriteLine("                             |                                                                 |");
            Console.WriteLine("                             |                                                                 |");
            Console.WriteLine("                             |                                                                 |");
            Console.WriteLine("                             |                                                                 |");
            Console.WriteLine("                             |                                                                 |");
            Console.WriteLine("                             |                                                                 |");
            Console.WriteLine("                             |                                                                 |");
            Console.WriteLine("                             |_________________________________________________________________|");
            int d, m, y;
            //-----------------
            L1 = true;
            L2 = true;
            L3 = true;
            bool L4 = true;
            bool revers = true;
            bool C = true;
            //these variable just for check and ending loop
            while (L1 == true)
            {
                Here:
                if(L1 == false)
                {
                    break;
                }
                if(revers != false)
                {
                    while (revers == true)
                    {
                        Console.ForegroundColor = ConsoleColor.Cyan;
                        Console.Write("                             - Enter The email : ");
                        email = Console.ReadLine();
                        string e = "";
                        if (ListEmail.Contains(email))
                        {
                            Console.ForegroundColor = ConsoleColor.Red;
                            Console.WriteLine("                             - This email is in the system");
                        }
                        else
                        {
                            Console.ForegroundColor = ConsoleColor.Cyan;
                            if (email.Contains('@'))
                            {
                                if (email.Length > 3)
                                {
                                    if (char.IsLetter(email[0]) && char.IsLetter(email[1]) && char.IsLetter(email[2]))
                                    {
                                        e += email[0];
                                        e += email[1];
                                        e += email[2];
                                        for (int i = 3; i < email.Length; i++)
                                        {
                                            if (char.IsLetterOrDigit(email[i]) || email[i] == '@' || email[i] == '.')
                                            {
                                                if (email[i] == '@')
                                                {
                                                    if (e.Contains('@'))
                                                    {
                                                        Console.ForegroundColor = ConsoleColor.Red;
                                                        Console.WriteLine("                             - Email have one (@)");
                                                        Console.ForegroundColor = ConsoleColor.Gray;
                                                        Console.WriteLine();
                                                        Console.WriteLine("                             - [0] To return to the main");
                                                        Console.WriteLine("                             - press (ENTER) to continue");
                                                        ret = Console.ReadLine();
                                                        if (ret == "0")
                                                        {
                                                            L1 = false;
                                                            goto Here;

                                                        }
                                                        else
                                                        {
                                                            break;
                                                        }
                                                    }
                                                    else
                                                    {
                                                        e += '@';
                                                    }
                                                }
                                                else
                                                {
                                                    e += email[i];
                                                }
                                                if (i == email.Length - 1)
                                                {
                                                    if (e.EndsWith("@gmail.com") || e.EndsWith("@hotmail.com"))
                                                    {
                                                        email = e;
                                                        revers = false;
                                                        break;
                                                    }
                                                    else
                                                    {
                                                        Console.ForegroundColor = ConsoleColor.Red;
                                                        Console.WriteLine("                             - Email must ends with (@gmail.com) or (@hotmail.com)");
                                                        Console.WriteLine();
                                                        Console.ForegroundColor = ConsoleColor.Gray;
                                                        Console.WriteLine("                             - [0] To return to the main ");
                                                        Console.WriteLine("                             - press (ENTER) to continue");
                                                        ret = Console.ReadLine();
                                                        if (ret == "0")
                                                        {
                                                            Console.Clear();
                                                            L1 = false;
                                                            goto Here;
                                                            
                                                        }
                                                    }
                                                }
                                            }
                                            else
                                            {
                                                Console.ForegroundColor = ConsoleColor.Red;
                                                Console.WriteLine();
                                                Console.WriteLine("                             - Email does not have whitespace");
                                                Console.ForegroundColor = ConsoleColor.Gray;
                                                Console.WriteLine("                             - [0] To return to the main ");
                                                Console.WriteLine("                             - press (ENTER) to continue");
                                                ret = Console.ReadLine();
                                                if (ret == "0")
                                                {
                                                    Console.Clear();
                                                    L1 = false;
                                                    goto Here;

                                                }
                                                else
                                                {
                                                    break;
                                                } 
                                            }
                                        }
                                    }
                                    else
                                    {
                                        Console.ForegroundColor = ConsoleColor.Red;
                                        Console.WriteLine("                             - Email must start with 3 character");
                                        Console.ForegroundColor = ConsoleColor.Gray;
                                        Console.WriteLine();
                                        Console.WriteLine("                             - [0] To return to the main");
                                        Console.WriteLine("                             - press (ENTER) to continue");
                                        ret = Console.ReadLine();
                                        if (ret == "0")
                                        {
                                            Console.Clear();
                                            L1 = false;
                                            goto Here;
                                        }
                                    }
                                }
                                else
                                {
                                    Console.ForegroundColor = ConsoleColor.Red;
                                    Console.WriteLine("                             - Email must Contains at least 4 character");
                                    Console.ForegroundColor = ConsoleColor.Gray;
                                    Console.WriteLine();
                                    Console.WriteLine("                             - [0] To return to the main");
                                    Console.WriteLine("                             - press (ENTER) to continue");
                                    ret = Console.ReadLine();
                                    if (ret == "0")
                                    {
                                        Console.Clear();
                                        L1 = false;
                                        goto Here;
                                    }
                                }
                            }
                            else
                            {
                                Console.ForegroundColor = ConsoleColor.Red;
                                Console.WriteLine("                             - Error index check your email");
                                Console.ForegroundColor = ConsoleColor.Gray;
                                Console.WriteLine();
                                Console.WriteLine("                             - [0] To return to the main");
                                Console.WriteLine("                             - press (ENTER) to continue");
                                ret = Console.ReadLine();
                                if (ret == "0")
                                {
                                    Console.Clear();
                                    L1 = false;
                                    goto Here;
                                }
                            }
                        }
                    }
                }
                else if(L2 != false)
                {
                    while (L2 == true)
                    {
                        Console.ForegroundColor = ConsoleColor.Cyan;
                        Console.Write("                             - Enter the password" +
                            " (You should put number and character to increase security) : ");
                        password = Console.ReadLine();
                        if (password.Length > 4)
                        {
                            Console.Write("                             - Enter the password again : ");
                            string p = Console.ReadLine();
                            if (password == p)
                            {
                                password = p;
                                L2 = false;
                                break;
                            }
                            else
                            {
                                Console.ForegroundColor = ConsoleColor.Red;
                                Console.WriteLine("                             - Password must be similer");
                                Console.ForegroundColor = ConsoleColor.Gray;
                                Console.WriteLine();
                                Console.WriteLine("                             - [0] To return to the main");
                                Console.WriteLine("                             - press (ENTER) to continue");
                                ret = Console.ReadLine();
                                if (ret == "0")
                                {
                                    Console.Clear();
                                    revers = true;
                                    L1 = false;
                                    goto Here;
                                }
                            }
                        }
                        else
                        {
                            Console.ForegroundColor = ConsoleColor.Red;
                            Console.WriteLine("                             - Password must be bigger than 4 ");
                            Console.ForegroundColor = ConsoleColor.Gray;
                            Console.WriteLine();
                            Console.WriteLine("                             - [0] To return to the main");
                            Console.WriteLine("                             - press (ENTER) to continue");
                            ret = Console.ReadLine();
                            if (ret == "0")
                            {
                                Console.Clear();
                                revers = true;
                                L1 = false;
                                goto Here;
                            }
                        }
                    }
                }
                else if (L3 != false)
                {
                    while (L3 == true)
                    {
                        Console.ForegroundColor = ConsoleColor.Cyan;
                        Console.Write("                             - Enter your name : ");
                        name = Console.ReadLine();
                        string n = "";
                        for (int i = 0; i < name.Length; i++)
                        {
                            if (char.IsLetter(name[i]) || char.IsWhiteSpace(name[i]))
                            {
                                n += name[i];
                                if (i == name.Length - 1)
                                {
                                    ListName.Add(n);
                                    L3 = false;
                                    break;
                                }
                            }
                            else
                            {
                                Console.WriteLine();
                                Console.ForegroundColor = ConsoleColor.Red;
                                Console.WriteLine("                             - Only chararcter in name");
                                Console.ForegroundColor = ConsoleColor.Gray;
                                Console.WriteLine();
                                Console.WriteLine("                             - [0] To return to the main");
                                Console.WriteLine("                             - press (ENTER) to continue");
                                ret = Console.ReadLine();
                                if (ret == "0")
                                {
                                    Console.Clear();
                                    revers = true;
                                    L1 = false;
                                    L2 = false;
                                    goto Here;
                                }
                                else
                                {
                                    break;
                                }
                            }
                        }
                    }
                }
                else if(C != false)
                {
                    while (C == true)
                    {
                        try
                        {
                            Console.ForegroundColor = ConsoleColor.Cyan;
                            Console.WriteLine("                             - Enter date : ");

                            Console.Write("                             - D : ");
                            d = Convert.ToInt32(Console.ReadLine());
                            Console.Write("                             - M : ");
                            m = Convert.ToInt32(Console.ReadLine());
                            Console.Write("                             - Y : ");
                            y = Convert.ToInt32(Console.ReadLine());
                            dob.set(d, m, y);
                            if (dob.CheckDate() == false)
                            {
                                ListDate.Add(Convert.ToString(d + "-" + m + "-" + y));
                                idOfShoppingcart++;
                                ListIdOfShoppingCart.Add(idOfShoppingcart);
                                C = false;
                            }
                            else C = true;
                        }
                        catch
                        {
                            Console.ForegroundColor = ConsoleColor.Red;
                            Console.WriteLine();
                            Console.WriteLine("                             - Error index.");
                            Console.WriteLine();
                            Console.ForegroundColor = ConsoleColor.Gray;
                        }

                    }
                }
                else if(L4 != false)
                {
                    long b;
                    while (L4 == true)
                    {
                        try
                        {
                            Console.ForegroundColor = ConsoleColor.Cyan;
                            Console.Write("                             - Enter account balance : ");
                            b = Convert.ToInt64(Console.ReadLine());
                            balance = b;
                            L4 = false;
                            break;
                        }
                        catch
                        {
                            Console.ForegroundColor = ConsoleColor.Red;
                            Console.WriteLine("                             - Only number");
                            Console.ForegroundColor = ConsoleColor.Gray;
                        }
                    }
                    Console.WriteLine();
                    Console.ForegroundColor = ConsoleColor.Blue;
                    Console.WriteLine("                             - ID of shopping cart : " + idOfShoppingcart);
                    Console.ForegroundColor = ConsoleColor.Green;
                    Console.WriteLine("                                               __________________________");
                    Console.WriteLine("                                               |                         |");
                    Console.WriteLine("                                               | Now you have an account |");
                    Console.WriteLine("                                               |_________________________|");
                    Console.WriteLine();
                }
                else if(revers == false && L2 == false && C == false && L3 == false && L4 == false)
                {
                    ListEmail.Add(email);
                    ListPassword.Add(password);
                    AccountBalance.Add(balance);
                    ret = Console.ReadLine();
                    Console.Clear();
                    L1 = false;
                }
            }
        }

        public override void PrintAll() //to print all your account information
        {
            Console.WriteLine();
            Console.WriteLine();
            Console.WriteLine();
            Console.ForegroundColor = ConsoleColor.Gray;
            Console.WriteLine("                             ^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^-^");
            Console.WriteLine("                             |                      -- About Account --                        |");
            Console.WriteLine("                             |                                                                 |");
            Console.WriteLine("                             |                                                                 |");
            Console.WriteLine("                             | [1] Create Account          [2] Get information of your account |");
            Console.WriteLine("                             |                                                                 |");
            Console.WriteLine("                             |                                                                 |");
            Console.WriteLine("                             |                     [3] Return                                  |");
            Console.WriteLine("                             |                                                                 |");
            Console.WriteLine("                             |                                                                 |");
            Console.WriteLine("                             |                                                                 |");
            Console.WriteLine("                             |                                                                 |");
            Console.WriteLine("                             |                                                                 |");
            Console.WriteLine("                             |                                                                 |");
            Console.WriteLine("                             |                                                                 |");
            Console.WriteLine("                             |_________________________________________________________________|");
            while (true)
            {
                Console.ForegroundColor = ConsoleColor.Cyan;
                Console.Write("                             - Enter your email for show your information : ");
                name = Console.ReadLine();
                Console.Write("                             - password of the email : ");
                password = Console.ReadLine();

                if (name.EndsWith("@gmail.com") || name.EndsWith("@hotmail.com"))
                {
                    if (ListEmail.Contains(name) && ListPassword.Contains(password))
                    {
                        Console.ForegroundColor = ConsoleColor.White;
                        int index = ListEmail.IndexOf(name);
                        Console.WriteLine();
                        Console.WriteLine("                             - Email : " + ListEmail[index]);
                        Console.WriteLine("                             - Password : " + ListPassword[index]);
                        Console.WriteLine("                             - Name : " + ListName[index]);
                        Console.WriteLine("                             - Date : " + ListDate[index]);
                        Console.WriteLine("                             - Balance : " + AccountBalance[index].ToString("f3"));
                        Console.WriteLine("                             - ID of shopping cart : " + ListIdOfShoppingCart[index]);
                        ret = Console.ReadLine();
                        Console.Clear();
                        break;
                    }
                    else
                    {
                        Console.ForegroundColor = ConsoleColor.Red;
                        Console.WriteLine("                             - This email is not in the system or the password you entered is not true : ");
                        Console.ForegroundColor = ConsoleColor.Gray;
                        Console.WriteLine("                             - [0] To return to the main");
                        Console.WriteLine("                             - press (ENTER) to continue");
                        ret = Console.ReadLine();
                        if (ret == "0")
                        {
                            Console.Clear();
                            break;
                        }
                    }
                }
                else
                {
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine("                             - Email must ends with (@gmail.com) or (@hotmail.com)");
                    Console.ForegroundColor = ConsoleColor.Gray;
                    Console.WriteLine("                             - [0] To return to the main");
                    Console.WriteLine("                             - press (ENTER) to continue");
                    ret = Console.ReadLine();
                    if (ret == "0")
                    {
                        Console.Clear();
                        break;
                    }
                }
            }
        }
        public override void PrintSpecificItem()
        {
        }
        public bool CheckAccount()// to check if you have an account or not
        {
            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.Write("                             - Enter your email : ");
            email = Console.ReadLine();
            Console.Write("                             - password of the email : ");
            password = Console.ReadLine();
            if ((ListEmail.Contains(email) && ListPassword.Contains(password)) && ((email.EndsWith("@gmail.com") || password.EndsWith("@hotmail.com"))))
            {
                return true;
            }
            else
            {
                Console.WriteLine();
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine("                             - Create account to enter this section");
                Console.WriteLine();
                ret = Console.ReadLine();
                Console.Clear();
                return false;
            }
        }
    }
}